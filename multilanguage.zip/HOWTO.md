# 1.Make website multilanguage from live edit
![Screenshot](https://raw.githubusercontent.com/microweber/microweber-docs/master/assets/multilanguage/live-edit-multilanguage.gif)

# 2.Edit custom page from live edit 
![Screenshot](https://raw.githubusercontent.com/microweber/microweber-docs/master/assets/multilanguage/live-edit-page-multilanguage.gif)

# 3.Make post multilanguage from admin
![Screenshot](https://raw.githubusercontent.com/microweber/microweber-docs/master/assets/multilanguage/admin-post-edit.gif)

# 4.Edit custom fields from live edit
![Screenshot](https://raw.githubusercontent.com/microweber/microweber-docs/master/assets/multilanguage/customfields-live-edit-multilanguage.gif)

# 5.Display custom name and icon
![Screenshot](https://raw.githubusercontent.com/microweber/microweber-docs/master/assets/multilanguage/dispaly-icon-multinaguage.gif)