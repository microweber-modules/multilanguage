<?php
namespace MicroweberPackages\Multilanguage\Models;

use Illuminate\Database\Eloquent\Model;

class MultilanguageSupportedLocales extends Model
{

}